<x-layout title="Nova Série">
    <form action="" method="post">
        <label for="nome">Nome:</label>
        <input type="text" id="nome" name="nome">
    </form>
</x-layout>
